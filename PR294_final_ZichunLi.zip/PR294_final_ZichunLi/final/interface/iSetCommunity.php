<?php
interface iSetCommunity
{
  public function setCommunity($community);
}