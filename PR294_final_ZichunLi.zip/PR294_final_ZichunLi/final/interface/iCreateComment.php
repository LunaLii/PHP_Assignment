<?php
interface iCreateComment
{
  public function createNewComment();
}