<?php
interface iGetUserInfo
{
  public function getUserEmail();
  public function getUserFirstName();
  public function getUserLastName();
  public function getUserTelephone();
}