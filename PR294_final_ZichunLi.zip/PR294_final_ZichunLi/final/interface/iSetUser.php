<?php
interface iSetUser
{
  public function setUser($userName,$password);
}