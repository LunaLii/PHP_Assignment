<?php
interface isError
{
  public function isError();
}