<?php
interface iSetUserInfo
{
  public function setUserInfo ($email,$firstName,$lastName,$telephone);
}