<?php
interface iDBSelect
{
  	public function selectDatabase();
}