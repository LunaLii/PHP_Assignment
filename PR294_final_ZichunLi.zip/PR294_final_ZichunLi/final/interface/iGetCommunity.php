<?php
interface iGetCommunity
{
  public function getCommunityTitle();
  public function getDescription();
  public function getCSS();
}