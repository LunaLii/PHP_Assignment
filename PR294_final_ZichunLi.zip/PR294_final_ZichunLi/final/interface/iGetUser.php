<?php
interface iGetUser
{
  public function getUser();
}