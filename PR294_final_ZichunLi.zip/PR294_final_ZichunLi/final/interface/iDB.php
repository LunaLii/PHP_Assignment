<?php
interface iDB
{
	public function connectToServer();
}