<?php
interface iTag
{
  public function setTag($comment);
  public function createNewTag($taggedName);
}