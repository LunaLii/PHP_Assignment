<?php
interface iQuery
{
	public function query($sql);  
}