<?php
interface iSetComment
{
	public function setComment ($content,$title,$userName,$parentNO=0,$levelNO=1,$commentNO=0,$replyNO=0, $postID=1);
	public function addCommentNO($currentNO);
  public function addReplyNO($currentNO);
	public function addLevelNO();
	
}