<?php
interface iSecurity
{
  public function sanitise($input);
  public function validate($input);
  public function manageSession();
  
}