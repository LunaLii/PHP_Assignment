<?php
interface iDBCreat
{
  	public function createDatabase();
}