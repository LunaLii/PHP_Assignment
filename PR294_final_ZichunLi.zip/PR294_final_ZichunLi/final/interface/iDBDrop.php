<?php
interface iDBDrop
{
    public function dropDatabase();
}