<?php
interface iGetComment
{
  public function getComment($db);
  public function getMaxCommentNO();
  public function getMaxReplyNO();
  
  
}