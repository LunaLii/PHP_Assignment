<?php
interface iOutput
{
	public function displayComment($temp);
	public function countCommentUser();
	public function countReplyUser($Id);
}