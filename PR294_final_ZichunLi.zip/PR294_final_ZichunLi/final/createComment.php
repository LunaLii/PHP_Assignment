<?php
include_once('comment.php');
require_once('MySQLDB.php');
include_once('tag.php');
include_once('security.php');
$host = 'localhost' ;
$dbUser = 'root';
$dbPass = '';
$dbName = 'community';
$db = new MySQL($host, $dbUser, $dbPass, $dbName);
$db->selectDatabase();


	if(isset($_POST['commentTitle']))
	{
    $security = new SecurityManager();
    $_POST['commentTitle'] = $security->sanitise($_POST['commentTitle']);
    $_POST['commentContent'] = $security->sanitise($_POST['commentContent']);
    $_POST['taggedUserName'] = $security->sanitise($_POST['taggedUserName']);	
    $_POST['commentTitle'] = $security->validate($_POST['commentTitle']);
    $_POST['commentContent'] = $security->validate($_POST['commentContent']);
    $_POST['taggedUserName'] = $security->validate($_POST['taggedUserName']);
	$commentTitle = $_POST['commentTitle'];
    $commentContent = $_POST['commentContent'];
    $taggedUserName = $_POST['taggedUserName'];
	$userName = $_SESSION['userName'];
	
    $theComment = new Comment($db);
    $theComment->setComment($commentContent, $commentTitle, $userName);
    $result = $theComment->getMaxCommentNO();
    $myrow = $result->fetch();
    $theComment->addCommentNO($myrow['MAX(commentNO)']);
    $theComment->createNewComment();
    
    $theTag = new Tag($db);
    $theTag->setTag($theComment);
    $theTag->createNewTag($taggedUserName);
    
    
    
	}	

