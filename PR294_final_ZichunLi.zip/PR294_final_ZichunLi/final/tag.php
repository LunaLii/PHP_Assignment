<?php
include_once('interface/iTag.php');
class Tag extends Comment implements iTag
{
  protected $db;
  protected $tagID;
  protected $commentID;
  protected $taggedUserName;
  
  public function __construct(iDB $db)
  {
    $this->db = $db;
   
  }
  
  public function setTag($comment)
  {
    $this->tagID = 0;
    $sql = "select Id from comment where commentNO = '$comment->commentNO' AND replyNO = '$comment->replyNO' AND parentNO = '$comment->parentNO' AND levelNO = '$comment->levelNO' AND userName = '$comment->userName'";
    $result = $this->db->query($sql);
    $myrow = $result->fetch();    
    $this->commentID = $myrow['Id'];
  }
  public function createNewTag($taggedName)
  {
    if (preg_match_all("/\@[a-zA-Z\d]*/", $taggedName, $names))
    {
      $names = $names[0];
      foreach ($names as $aName) {
        $this->taggedUserName = str_replace('@', '', $aName);
        $this->db->query("insert into tag values (
            null, 
            '$this->commentID',
            '$this->taggedUserName'      
            )");
      }
    }
    
  }
}