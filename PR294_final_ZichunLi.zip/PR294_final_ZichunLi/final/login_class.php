<?php
include_once('userInfo.php');
include_once('interface/iGetUser.php');
include_once('interface/iSetUser.php');
class Login extends UserInfo implements iSetUser, iGetUser
{

  public function setUser($userName,$password)
  {
    $this->userName = $userName;
    $this->password = $password;
  }
  
  public function getUser()
  {
    $sql = "select * from userInfo where userName = '$this->userName'";
    $result = $this->db->query($sql);
    $myrow = $result->fetch();
    $hash = $myrow['password'];
    $login = $this->userName . $this->password;
    if (password_verify($login, $hash))
    {
      return $userName = $myrow['userName'];
    }
    else
    {
      return false;
    }
  }
  
  
  
  
  
}