<?php
include_once('interface/iSetUserInfo.php');
include_once('interface/iGetUserInfo.php');
class UserInfo implements iSetUserInfo, iGetUserInfo
{
  protected $db;
  protected $userName;
  protected $password;
  protected $email;
  protected $firstName;
  protected $lastName;
  protected $telephone;
  
  function __construct(iDB $db)
  {
    $this->db = $db;
  }
  
  public function setUserInfo ($email,$firstName,$lastName,$telephone)
  {
    $this->email = $email;
    $this->firstName = $firstName;
    $this->lastName = $lastName;
    $this->telephone = $telephone;
  }
  
  public function setUser($userName,$password)
  {
    
  }
  
  public function getUser()
  {
    
  }
  
  public function getUserEmail()
  {
    return $this->email;
  }
  
  public function getUserFirstName()
  {
    return $this->firstName;
  }
  
  public function getUserLastName()
  {
    return $this->lastName;
  }
  
  public function getUserTelephone()
  {
    return $this->telephone;
  }
  
  
}
  
  
  
  
  
  