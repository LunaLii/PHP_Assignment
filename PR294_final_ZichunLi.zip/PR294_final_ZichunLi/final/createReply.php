<?php
include_once('comment.php');
require_once('MySQLDB.php');
include_once('security.php');
include_once('tag.php');

$host = 'localhost' ;
$dbUser = 'root';
$dbPass = '';
$dbName = 'community';
$db = new MySQL($host, $dbUser, $dbPass, $dbName);
$db->selectDatabase();



	if(isset($_POST['replyTitle']))
	{
    $security = new SecurityManager();
    $_POST['replyTitle'] = $security->sanitise($_POST['replyTitle']);
    $_POST['replyContent'] = $security->sanitise($_POST['replyContent']);
    $_POST['taggedUserName'] = $security->sanitise($_POST['taggedUserName']);	
    $_POST['replyTitle'] = $security->validate($_POST['replyTitle']);
    $_POST['replyContent'] = $security->validate($_POST['replyContent']);
    $_POST['taggedUserName'] = $security->validate($_POST['taggedUserName']);
	$replyTitle = $_POST['replyTitle'];
    $replyContent = $_POST['replyContent'];
    $theComment = $_POST['theComment'];
    $theReply = $_POST['theReply'];
    $theLevel = $_POST['theLevel'];
    $theParent = $_POST['theParent'];
	$userName = $_SESSION['userName'];
    $taggedUserName = $_POST['taggedUserName'];
	
    $aReply = new Comment($db);
    $aReply->setComment($replyContent, $replyTitle, $userName,$theParent, $theLevel, $theComment);
    $result = $aReply->getMaxReplyNO();
    $myrow = $result->fetch();
    $aReply->addReplyNO($myrow['MAX(replyNO)']);	

    $aReply->addLevelNO();
    $aReply->createNewComment();
    
    $theTag = new Tag($db);
    $theTag->setTag($aReply);
    $theTag->createNewTag($taggedUserName);
	}

	
	
