<?php
session_start();
include_once('createComment.php');
include_once('createReply.php');
require_once('MySQLDB.php');
$host = 'localhost' ;
$dbUser = 'root';
$dbPass = '';
$dbName = 'community';
$db = new MySQL($host, $dbUser, $dbPass, $dbName);
$db->selectDatabase();

$lan_array = parse_ini_file('language.ini',true);
$language = $_SESSION['language'];
$communityTitle = $_SESSION['communityTitle'];

$session = new SecurityManager();
$session->manageSession();
?>


<!DOCTYPE html>
<html>
<head>
	<title>Community</title>
	<script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
	<link rel="stylesheet" href="<?php echo $_SESSION['communityCSS'];?>">
</head>

<body>
	<header>
		<p><span class="highlight"><?php echo $lan_array[$language]['Hello'];?></span>  <span class="underline"><?php echo $_SESSION['userName'];?></span>. <span class="highlight"><?php echo $lan_array[$language]['Welcome to the community'];?>.</span> </p>
		<h1><?php 
		echo $lan_array[$language] [$communityTitle]; ?></h1>
	</header> 
	<main>
		
		<div id="app">
		<?php
/* 		require_once('MySQLDB.php');
		$host = 'localhost' ;
		$dbUser = 'root';
		$dbPass = '';
		$dbName = 'community';
		$db = new MySQL($host, $dbUser, $dbPass, $dbName);
		$db->selectDatabase();
 */
		include_once('commentOutput.php');
		$sql = "select * from post";
		$result = $db->query($sql);
		$button = $lan_array[$language]['Comment'];
		$count = $lan_array[$language]['The number of users who have commented'];
		
		while ($myrow = $result->fetch())
		{
			$postTitle = $myrow['postTitle'];
			$postContent = $myrow['postContent'];
			$aComment = new CommentOutput($db);
			$theCount = $aComment->countCommentUser();
			echo "<h1>$postTitle</h1>
					</br>
					<p>$postContent</p>
					<p class='highlight'>$count: $theCount</p>
					<button v-on:click=displayComment class=btn>$button</button>";
		}
		

		?>
			<form v-if="comment" class="container" action="main.php" method="POST">
				<h1><?php echo $lan_array[$language]['Comment']; ?></h1>
				
				
				<div class="comment-box">
					<label for="commentTitle"><?php echo $lan_array[$language] ['Comment Title']; ?></label>
					<input type="text" maxlength="50" name="commentTitle" id="commentTitle" required></input>
					</br>
					<label for="commentContent"><?php echo $lan_array[$language] ['Comments']; ?></label>
					<textarea id="commentContent" maxlength="1000" name="commentContent" placeholder="<?php echo $lan_array[$language] ['Write your comments']; ?>"></textarea>
					</br>
					<label for="tag"><?php echo $lan_array[$language] ['Tag']; ?></label>
					<input type="text" maxlength="50" name="taggedUserName" id="tag"></input>
				</div>
				
				<input type="submit" value="<?php echo $lan_array[$language] ['SUBMIT']; ?>" class="btn" v-on:click="hideComment"></input>
			</form >
			
			<form v-if="reply" class="container" action="main.php" method="POST">
				<h1><?php echo $lan_array[$language] ['Reply']; ?></h1>
				<div class="comment-box">
					<label for="replyTitle"><?php echo $lan_array[$language] ['Reply Title']; ?></label>
					<input type="text" maxlength="50" name="replyTitle" id="replyTitle" required></input>
					</br>
					<label for="replyContent"><?php echo $lan_array[$language] ['Reply']; ?></label>
					<input type="hidden" name="theComment" :value="commentNO" />
					<input type="hidden" name="theReply" :value="replyNO" />
					<input type="hidden" name="theLevel" :value="levelNO" />
					<input type="hidden" name="theParent" :value="parentNO" />
					<textarea id="replyContent" maxlength="1000" name="replyContent" placeholder="<?php echo $lan_array[$language] ['Write your reply']; ?>"></textarea>
					</br>
					<label for="tag"><?php echo $lan_array[$language] ['Tag']; ?></label>				
					<input type="text" maxlength="50" name="taggedUserName" id="tag"></input>
				</div>
				
				<input type="submit" value="<?php echo $lan_array[$language] ['SUBMIT']; ?>" class="btn" v-on:click="hideReply"></input>
			</form>
			<?php
			include_once('commentOutput.php');
			$aComment = new CommentOutput($db);
			$comments = $aComment->getComment($db);
			$aComment->displayComment($comments);
			?>
		</div>
	</main>
	<script>
	var app = new Vue({
		el: '#app',
		data: {
			comment: false,
			reply:false,
			commentNO: '',
			replyNO: '',
			levelNO: '',
			parentNO:''
		},
		methods: {
			displayComment: function() {
				this.comment = true
				this.reply = false
			},
			hideComment: function() {
				this.comment = false
				this.reply = false
			},
			displayReply: function(commentNO,replyNO,levelNO,parentNO) {
				this.reply = true
				this.comment = false
				this.commentNO = commentNO
				this.replyNO = replyNO
				this.levelNO = levelNO
				this.parentNO = parentNO
			},
			hideReply: function() {
				this.reply = false
				this.comment = false
				
			}
		}
		
	});
	</script>
</body>
</html>