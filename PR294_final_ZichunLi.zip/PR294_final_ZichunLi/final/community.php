<?php
include_once('interface/iSetCommunity.php');
include_once('interface/iGetCommunity.php');
class Community implements iSetCommunity, iGetCommunity
{
	protected $db;
	protected $communityName;
	protected $communityTitle;
	protected $description;
	protected $CSS;
	
	public function __construct(iDB $db)
	{
		$this->db = $db;
	}
	
	public function setCommunity($community)
	{
		$sql = "select * from community where communityName = '$community'";
		$result = $this->db->query($sql);
		$myrow = $result->fetch();
		$this->communityName = $myrow['communityName'];
		$this->communityTitle = $myrow['communityTitle'];
		$this->description = $myrow['description'];
		$this->CSS = $myrow['CSS'];
	}
	
	public function getCommunityTitle()
	{
		return $this->communityTitle;
	}
	
	public function getDescription()
	{
		return $this->description;
	}
	public function getCSS()
	{
		return $this->CSS;
	}
}