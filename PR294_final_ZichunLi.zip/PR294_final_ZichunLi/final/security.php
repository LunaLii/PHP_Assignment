<?php
include_once('interface/iSecurity.php');
class SecurityManager implements iSecurity
{
/*   protected $db;

  function __construct(iDB $db)
  {
    $this->db = $db;
  } */
  
  public function sanitise($input)
  {
    $input = $input;

    $input = filter_var($input, FILTER_SANITIZE_STRING);
    return $input;
  }
  
  public function validate($input)
  {
    $input = trim($input);
    $input = htmlentities($input,ENT_NOQUOTES);
    return $input;
  }

  public function manageSession()
  {
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
      session_unset();
      session_destroy();
	  header ('Location: login.php');
    }
    $_SESSION['LAST_ACTIVITY'] = time();    
    if (!isset($_SESSION['generated'])) {
      $_SESSION['generated'] = time();
    } 
	else if (time() - $_SESSION['generated'] > 60) 
	{
      session_regenerate_id(true);
      $_SESSION['generated'] = time();
    }
  }
}
