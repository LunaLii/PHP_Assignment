<?php
require_once('MySQLDB.php');
$host = 'localhost' ;
$dbUser = 'root';
$dbPass = '';
$dbName = 'community';
$db = new MySQL($host, $dbUser, $dbPass, $dbName);
$db->selectDatabase();

$sql = "select * from post";
$result = $db->query($sql);
while ($myrow = $result->fetch())
{
	$postTile = $myrow['postTile'];
	$postContent = $myrow['postContent'];
	echo "<h1>$postTile</h1>
			</br>
			<p>$postContent</p>
			<button v-on:click="displayComment" class="btn">Comment</button>"
			;
}