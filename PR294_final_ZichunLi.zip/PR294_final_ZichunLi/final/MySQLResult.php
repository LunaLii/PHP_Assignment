<?php
include_once('interface/iResult.php');

class MySQLResult implements iResult
{
   protected $mysql;
   protected $query;

   public function __construct( $newMysql, $newQuery )
   {
		$this->mysql = $newMysql;
		$this->query = $newQuery;
   }

    public function size()
    {
		return mysqli_num_rows($this->query);
    }

    public function fetch()
    {
       if ( $row = mysqli_fetch_array( $this->query , MYSQLI_ASSOC ))
       {
			return $row;
       }
       else if ( $this->size() > 0 )
       {
			mysqli_data_seek( $this->query , 0 );
			return false;
       }
       else
       {
			return false;
       }         
    }
	
	public function insertID()
    {
      return mysqli_insert_id( $this->mysql->dbConn );
    }


   public function isError()
    {
      return $this->mysql->isError();
    }
}