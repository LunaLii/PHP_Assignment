<?php
include_once('createLogin.php');
require_once('MySQLDB.php');
$host = 'localhost' ;
$dbUser = 'root';
$dbPass = '';
$dbName = 'community';
$db = new MySQL($host, $dbUser, $dbPass, $dbName);
$db->selectDatabase();




?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<link rel="stylesheet" href="css/stylesheet.css">
</head>
<body>
	<header>
	</header>
	<main>
		<form class="container" action="login.php" method="POST">
      <h1>Login</h1>
			<div class="input-box">
        <i class="fa fa-user" aria-hidden="true"></i>
				<input type="text" name="userName" id="userName" placeholder="User Name / E-mail Address" required>
			</div>
			
			<div class="input-box">
      <i class="fa fa-lock" aria-hidden="true"></i>
			<input type="password" name="password" id="password" placeholder="Password" required>
			</div>
			<label for="community">Select the community</label>
			<select name="community" id="community" required>
				<option value="game">Theseus and the minotaur</option>
				<option value="language">Hindi Language learning</option>
			</select>
			</br>
			</br>
			<label for="language">Select the language</label>
			<select name="language" id="language" required >
				<option value="En"">English</option>
				<option value="Hindi">Hindi</option>
			</select>
			
			<button type="submit" name="submit" class="btn">Login</button>
			<a href="sign-up.html" class="sign-up-btn">Sign Up Now</a>
		</form>
	</main>
</body>
</html>