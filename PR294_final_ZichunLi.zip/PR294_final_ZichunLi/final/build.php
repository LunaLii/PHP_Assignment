<?php
/* $ex = "building tasks";
echo "$ex<br><br>"; */
include_once('MySQLDB.php');
$host = 'localhost' ;
$dbUser = 'root';
$dbPass = '';
$dbName = 'community';


// create a new database object and connect to server
$db = new MySQL($host, $dbUser, $dbPass, $dbName);
    
// Check connection
//$db->dropDatabase();
$db->createDatabase();

// select the database
$db->selectDatabase();

     
// drop table


// execute the sql


//drop tables if exists
$sql = "drop table if exists tag";
$result = $db->query($sql);


$sql = "drop table if exists comment";
$result = $db->query($sql);

$sql = "drop table if exists post";
$result = $db->query($sql);

$sql = "drop table if exists userInfo";
$result = $db->query($sql);

$sql = "drop table if exists community";
$result = $db->query($sql);




//------------------------------------------------------------
// create table
// community table
$sql = "create table community (
	communityName varchar(50) primary key,
	communityTitle varchar(100),
	description varchar(1000),
	CSS varchar(100)
	)";

$result = $db->query($sql);
if (!$result)
{
	echo 'the userInfo table was NOT created';
}
	
//userInfo table
$sql = "create table userInfo ( 
    userName varchar(20) NOT NULL UNIQUE PRIMARY KEY,
    password varchar(300),
    email varchar(40),
    firstName  varchar(20),
    lastName varchar(20),
    telephone int(20) )";

// execute the sql
$result = $db->query($sql);
if (!$result)
{
	echo 'the userInfo table was NOT created';
}

//post table
$sql = "create table post (
	postID INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
    postTitle varchar(30),
	postContent varchar(1000),
    postTime TIMESTAMP,
    userName varchar(20),
	foreign key(userName) references userInfo(userName)
	)";
// execute the sql
$result = $db->query($sql);
if (!$result)
{
	echo 'the POST table was NOT created';
}

//comment table
$sql = "create table comment (
	Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	commentNO INT,
	replyNO INT,
	levelNO INT,
	parentNO INT,
	userName varchar(20),
	postID INT,
	title varchar(200),
	content varchar(2000),
	time date,
	foreign key(userName) references userInfo(userName),
	foreign key(postID) references post(postID)
	)";

// execute the sql
$result = $db->query($sql);
if (!$result)
{
	echo 'the comment table was NOT created';
}


//tag table
$sql = "create table tag (
	tagID INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
	commentID INT,
    taggedUserName varchar(20),
    foreign key(commentID) references comment(Id),
	foreign key(taggedUserName) references userInfo(userName)
	)";
// execute the sql
$result = $db->query($sql);
if (!$result)
{
	echo 'the tag table was NOT created';
}

//insert two communities into community table
$sql = "insert into community values ('game', 'Theseus and the minotaur community', 'This is a community about theseus and minotaur.','css/stylesheet2.css')";
$result = $db->query($sql);

$sql = "insert into community values ('language','Hindi Language learning community', 'This is a community about Hindi language learning.','css/stylesheet1.css')";
$result = $db->query($sql);

// insert some rows into userInfo table
$userName = 'Lily';
$password = '1234';
$login = $userName . $password;
$hash = password_hash($login, PASSWORD_DEFAULT);
$sql = "insert into userInfo values ('$userName','$hash', 'lily123@gmail.com', 'Lily', 'White', 1234556)";
$result = $db->query($sql);

$userName = 'Tom';
$password = '9900';
$login = $userName . $password;
$hash = password_hash($login, PASSWORD_DEFAULT);
$sql = "insert into userInfo values ('$userName','$hash', 'tom@gmail.com', 'Tom', 'White', 2205544)";
$result = $db->query($sql);

$userName = 'Jack';
$password = '2233';
$login = $userName . $password;
$hash = password_hash($login, PASSWORD_DEFAULT);
$sql = "insert into userInfo values ('$userName','$hash', 'jack@gmail.com', 'Jack', 'White', 2115544)";
$result = $db->query($sql);
// insert some rows into post table
$sql = "insert into post values (NULL, 'Post 1 Title', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor.', '2018-10-31 12:30:11', 'Lily')";
$result = $db->query($sql);

/* update*/
$sql = "update userInfo set email = '1234@gmail.com' where userName = 'Tom'";
$result = $db->query($sql);

/* $sql = "insert into post values (NULL, 'Post 2 Title', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor.', '2018-11-1 12:30:11', 'Tom')";
$result = $db->query($sql); */



//insert rows into comment table
/* $sql = "insert into comment values (NULL, 1, 0, 1, 0, 'Lily', 1, 'test1', 'comment1', '2018-10-31 15:30:11')";
$result = $db->query($sql);
$sql = "insert into comment values (NULL, 2, 0, 1, 0, 'Tom', 1, 'test2', 'comment2', '2018-10-31 19:30:11')";
$result = $db->query($sql); */


//insert rows into tag table


//get data from comment table
/* $sql = "select * from comment where userID = 2";
$result = $db->query($sql);
$myrow = $result->fetch();
$commentID = $myrow['commentID'];
$userID = $myrow['userID'];
$postID = $myrow['postID'];
$commentContent = $myrow['commentContent'];
$commentTitle = $myrow['commentTitle'];
$commentTime = $myrow['commentTime']; */

//modify existing data
/* function deleteComment()
{
	$sql = "DELETE from comment where commentID = 1";
	$result = $db->query($sql);
} */

/* function updateUserInfo()
{
	$sql = "update userInfo
			set email = '$this->email',
				firstName = '$this->firstName',
				lastName = '$this->lastName',
				telephone = '$this->telephone'";
	$result = $db->query($sql);
} */

//Simple (select * or a few fields query) and display
/* function selectDisplay()
{
	$sql = "select * from comment where userName = '$this->userName'";
	$result = $db->query($sql);
	echo '<table>';
	while($myrow = $result->fetch())
	{
		$commentID = $myrow['commentID'];
		$userName = $myrow['userName'];
		$postID = $myrow['postID'];
		$commentContent = $myrow['commentContent'];
		$commentTitle = $myrow['commentTitle'];
		$commentTime = $myrow['commentTime'];
		print "<tr><td>$commentID</td><td>$userName</td><td>$postID</td><td>$commentContent</td><td>$commentTitle</td><td>$commentTime</td></tr>" ;
	}
	echo '</table>';
} */


?>
<html>
<body>

<br><br>



</body>
</html>
