<?php
include_once('login_class.php');
require_once('MySQLDB.php');
include_once('security.php');
include_once('community.php');

$host = 'localhost' ;
$dbUser = 'root';
$dbPass = '';
$dbName = 'community';
$db = new MySQL($host, $dbUser, $dbPass, $dbName);
$db->selectDatabase();

if ($_SERVER['REQUEST_METHOD'] === 'POST')
{
	
	if (isset($_POST['userName']))
	{
	  $security = new SecurityManager();
	  $_POST['userName'] = $security->sanitise($_POST['userName']);
	  $_POST['password'] = $security->sanitise($_POST['password']);
	  $_POST['userName'] = $security->validate($_POST['userName']);
	  $_POST['password'] = $security->validate($_POST['password']);
	  $userName = $_POST['userName'];
	  $password = $_POST['password'];
	}
	
	if (isset($_POST['community']))
	{
		$community = $_POST['community'];
	}
	
	if (isset($_POST['language']))
	{
		$language = $_POST['language'];
		
	}
	else
	{
		$language = 'En';
		
	}
	$lan_array = parse_ini_file('language.ini',true);
	  /* $sql = "select * from userInfo where userName='$userName'";
		$result = $db->query($sql);
		echo "<br>";
		$row = $result->fetch();
		$hash = $row['password'];

		$login = $userName . $password;
		if (password_verify($login, $hash))
		{
			echo 'login is valid<br>';        
			$_SESSION['userName'] = $row['username'];
			header('Location: main.php');
		}
		else 
		{
			echo 'login failed<br>';
		} */
	  $theLogin = new Login($db);
	  $theLogin->setUser($userName,$password);
	  $myLogin = $theLogin->getUser();
	  
	  $theCommunity = new Community($db);
	  $theCommunity->setCommunity($community);
	  $communityTitle = $theCommunity->getCommunityTitle(); 
	  $communityCSS = $theCommunity->getCSS();
	  if (!$myLogin)
	  {
		echo 'Login failed';
		
	  }
	  else
	  {
		session_start();
		$_SESSION['userName'] = $myLogin;
		$_SESSION['communityTitle'] = $communityTitle;
		$_SESSION['communityCSS'] = $communityCSS;
		$_SESSION['language'] = $language;
		header('Location: main.php');
		echo 'login successfully';
	  }

	
}