<?php
include_once('interface/iOutput.php');
class CommentOutput extends Comment implements iOutput
{
	public function displayComment($temp) 
    {
    $lan_array = parse_ini_file('language.ini',true);
    $language = $_SESSION['language'];
    $CommentNO =$lan_array[$language]['Comment NO'];
    $ReplyNO =$lan_array[$language]['Reply NO'];
    $LevelNO =$lan_array[$language]['Level NO'];
    $ReplyTo =$lan_array[$language]['Reply To'];
    $UserName =$lan_array[$language]['User Name'];
    $PostID =$lan_array[$language]['Post ID'];
    $Title =$lan_array[$language]['Title'];
    $Content =$lan_array[$language]['Content'];
    $Time =$lan_array[$language]['Time'];
    $tag = $lan_array[$language]['Tagged User'];
    $number = $lan_array[$language]['The number of users who have replyed'];
    echo "<table><tr><th>ID</th><th>$CommentNO</th><th>$ReplyNO</th><th>$LevelNO</th><th>$ReplyTo</th><th>$UserName</th><th>$PostID</th><th>$Title</th><th>$Content</th><th>$tag</th><th>$Time</th><th> </th><th>$number</th>";
    while($myrow = $temp->fetch())
    {
      $Id = $myrow['Id'];
      $commentNO = $myrow['commentNO'];
      $postID = $myrow['postID'];
      $commentContent = $myrow['content'];
      $commentTitle = $myrow['title'];
      $commentTime = $myrow['time'];
      $replyNO = $myrow['replyNO'];
      $levelNO= $myrow['levelNO'];
      $parentNO = $myrow['parentNO'];
      $userName = $myrow['userName'];
      $taggedUserName = $myrow['taggedUserName'];
      $button = $lan_array[$language]['Reply'];
      $theCount = $this->countReplyUser($Id);
      print "<tr><td>$Id</td><td>$commentNO</td><td>$replyNO</td><td>$levelNO</td><td>$parentNO</td><td>$userName</td><td>$postID</td><td>$commentTitle</td><td>$commentContent</td><td>$taggedUserName</td><td>$commentTime</td><td><button v-on:click=displayReply($commentNO,$replyNO,$levelNO,$Id)>$button</button></td><td>$theCount</td></tr>" ;
    }
    echo '</table>';
    }
	
	public function countCommentUser()
    {
	  $sql = "select count(distinct(userName)) as theCount from comment";
	  $result = $this->db->query($sql);
	  $myrow = $result->fetch();
	  return $theCount = $myrow['theCount'];
    }
  
	public function countReplyUser($Id)
	{
	  $sql = "select count(distinct(userName)) as theCount from comment where parentNO = '$Id'";
	  $result = $this->db->query($sql);
	  $myrow = $result->fetch();
	  return $theCount = $myrow['theCount'];
    }
}