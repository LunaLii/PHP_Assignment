<?php

include_once('interface/iDB.php');
include_once('interface/iDBDrop.php');
include_once('interface/iQuery.php');
include_once('interface/isError.php');
include_once('interface/iDBCreat.php');
include_once('interface/iDBSelect.php');
include_once('MySQLResult.php');
class MySQL implements iDB,iQuery,isError,iDBSelect,iDBCreat,iDBDrop
{
	protected  $host;
	protected  $dbUser;
	protected  $dbPass;
	protected  $dbName;
	protected  $dbConn;
	protected  $dbconnectError;

	public function __construct( $host, $dbUser, $dbPass, $dbName )
	{
	 $this->host   = $host;
	 $this->dbUser = $dbUser;
	 $this->dbPass = $dbPass;
	 $this->dbName = $dbName;
	 $this->connectToServer();
	}

	public function connectToServer()
	{
	   $this->dbConn = mysqli_connect($this->host, $this->dbUser, $this->dbPass );
	   if (!$this->dbConn )
	   {
		  trigger_error ('could not connect to server' );
		  $this->dbconnectError = true;
	   }
	}

	 public function selectDatabase()
	{
	if (! mysqli_select_db( $this->dbConn, $this->dbName ) )
		   {
				trigger_error('could not select database' );  
				$this->dbconnectError = true;                     
		   }

	}
 
	public function dropDatabase()
	{
		$sql = "drop database $this->dbName";
		echo "$sql</br>";
		if($this->query($sql))
		{
			echo "the database was dropped";
		}
	}
	public function createDatabase()
	{
		$sql = "create database if not exists $this->dbName";
		echo "$sql  <br />";
		if ( !$this->query($sql) )
		{
			echo "failed to create the $this->dbName database<br>";
		}
	}	   

   public function isError()
   {
		if  ( $this->dbconnectError )
		{
			return true;
		}
		$error = mysqli_error ( $this->dbConn );
		if ( empty ($error) )
        {
			return false;
        }
        else
        {
			return true;   
        }
   }
   public function query( $sql )
   {

		if ( ! $queryResource = mysqli_query( $this->dbConn, $sql ) )
		{
			trigger_error( 'Query Failed: ' . mysqli_error($this->dbConn ) . ' SQL: ' . $sql );
			return false;
		}
		return new MySQLResult( $this, $queryResource ); 
   }
}




