<?php
include_once('interface/iCreateComment.php');
include_once('interface/iGetComment.php');
include_once('interface/iSetComment.php');
class Comment implements iSetComment, iGetComment, iCreateComment
{
  protected $db;
  protected $Id;
  protected $commentNO;
  protected $replyNO;
  protected $levelNO;
  protected $parentNO;
  protected $userName;
  protected $postID;
  protected $title;
  protected $content;
  protected $time;
  
  function __construct(iDB $db)
  {
    $this->db = $db;
  }
  public function setComment ($content,$title,$userName,$parentNO=0,$levelNO=1,$commentNO=0,$replyNO=0, $postID=1)
  {
	$this->Id = 0;
	$this->commentNO = $commentNO;
	$this->replyNO = $replyNO;
	$this->levelNO = $levelNO;
	$this->parentNO = $parentNO;	
    $this->userName = $userName;
    $this->postID = $postID;
    $this->title = $title;
    $this->content = $content;
    $this->time = date("Y-m-d H:i:s");
  }

  public function createNewComment() 
  {
    $sql = "Insert into comment Values($this->Id,$this->commentNO,$this->replyNO,$this->levelNO,$this->parentNO,'$this->userName',$this->postID,'$this->title','$this->content','$this->time')";
	$result = $this->db->query($sql);	
  }
  
  public function getComment($db)
  {
	$sql = "select * from comment left join tag on comment.Id = tag.commentID order by Id ASC";
    $result = $db->query($sql);
	return $result;
  }
  
  public function getMaxCommentNO()
  {
	$sql = "select MAX(commentNO) from comment";
	$result = $this->db->query($sql);
	return $result;
  }
  public function addCommentNO($currentNO)
  {
	if ($currentNO === NULL)
	{
	  $this->commentNO = 1;
	}
	else
	{
	  $this->commentNO = (int)$currentNO + 1;
	}
  }
  
  public function getMaxReplyNO()
  {
	$sql = "select MAX(replyNO) from comment where parentNO = '$this->parentNO'";
	$result = $this->db->query($sql);
	return $result;
  }
  
  public function addReplyNO($currentNO)
  {
	  $this->replyNO = (int)$currentNO + 1;
  }
  
  public function addLevelNO()
  {
	  $this->levelNO += 1;
  }
   
  public function displayComment($temp)
  {
	  
  }
  
  public function countCommentUser()
  {
	  
  }
  
  public function countReplyUser($Id)
  {
	  
  }
/*   public function countCommentUser()
  {
	  $sql = "select count(distinct(userName)) as theCount from comment";
	  $result = $this->db->query($sql);
	  $myrow = $result->fetch();
	  return $theCount = $myrow['theCount'];
  }
  
  public function countReplyUser($Id)
  {
	  $sql = "select count(distinct(userName)) as theCount from comment where parentNO = '$Id'";
	  $result = $this->db->query($sql);
	  $myrow = $result->fetch();
	  return 	  $theCount = $myrow['theCount'];
  } */
}